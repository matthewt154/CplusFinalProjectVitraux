# CplusFinalProjectVitraux
Projet final pour le cours de C++ Uottawa Automne 2019

Professeur Robert Laganière

Contributeurs:
Matthew Tran
Mathieu Bellefeuille

Jeu de 2 personnes sur même console pour placer des vitraux. 

